//
//  SearchViewController.swift
//  Final Project
//
//  Created by shabnam patel.
//

// to search location for start location and end location of route

import UIKit
import MapKit

class SearchViewController: UIViewController, UISearchBarDelegate, MKLocalSearchCompleterDelegate, UITableViewDelegate, UITableViewDataSource {
    
    //objects
    private let searchCompleter = MKLocalSearchCompleter()
    private var searchResults = [MKLocalSearchCompletion]()
    
    //to store from and to location screen
    var field : (String, String)?

    @IBOutlet weak var searchBar: UISearchBar!
    @IBOutlet weak var tableView: UITableView!
    
    override func viewDidLoad() {
        
        //delegates
        super.viewDidLoad()
        searchBar.delegate = self
        searchCompleter.delegate = self
        tableView.delegate = self
        tableView.dataSource = self
        searchBar.text = field?.1
        searchBar.becomeFirstResponder()
    }
    
//on selecting locationn assigning text to previous view and closing current
    private func apply() {
        let presenter = self.presentingViewController?.children.last as? RoutesViewController
        
        if field?.0 == "fromField" {
            presenter?.fromField.text = searchBar.text
        } else {
            presenter?.toField.text = searchBar.text
        }
        dismiss(animated: true, completion: nil)
    }
    
    //for search bar text change event
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        //if text is not empty then perform search
        if !searchText.isEmpty {
            searchCompleter.queryFragment = searchText
        }
    }
    
    
    //cancel button
    @IBAction func dismissBtn(_ sender: Any) {
        dismiss(animated: true, completion: nil)
    }
    
    
    //searchbar search button clicked event handler
    func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
        
        searchBar.resignFirstResponder()
        apply()
    }
    
    //method to update list on text change in search box
    func completerDidUpdateResults(_ completer: MKLocalSearchCompleter) {
        searchResults = completer.results
        DispatchQueue.main.async {
            self.tableView.reloadData()
        }
    }
    
    
    //error handler
    func completer(_ completer: MKLocalSearchCompleter, didFailWithError error: Error) {
        print(error.localizedDescription)
    }
    
    // serach result array count for numbers of row
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return searchResults.count
    }
    
    //assigning value to cell in table view
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        cell.textLabel?.text = searchResults[indexPath.row].title
        return cell
    }
    
    
    //for selected row from table view
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        
        searchBar.text = tableView.cellForRow(at: indexPath)?.textLabel?.text
        apply()
    }

}

