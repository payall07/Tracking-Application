//
//  RoutesViewController.swift
//  Final Project
//
//  Created by Parth Patel
//

//route classs for finding route from user provided one location to another

import UIKit
import UIKit
import MapKit
import CoreLocation

class RoutesViewController: UIViewController , MKMapViewDelegate, UITextFieldDelegate{
    
    //objects
    private let locationManager = CLLocationManager()
    private var sourceLocation : CLLocationCoordinate2D?
    private var destinationLocation : CLLocationCoordinate2D?
    private let dispatchGroup = DispatchGroup()
    private let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
    var currentLocationFlag = false
    
    @IBOutlet weak var fromField: UITextField!
    @IBOutlet weak var toField: UITextField!
    @IBOutlet weak var mapView: MKMapView!
    @IBOutlet weak var fromBtn: UIButton!
    @IBOutlet weak var toBtn: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //delegates
        fromField.delegate = self
        toField.delegate = self
        
        //location request
        locationManager.requestAlwaysAuthorization()
        locationManager.requestWhenInUseAuthorization()
        
        //location manager properties
        if CLLocationManager.locationServicesEnabled() {
            locationManager.desiredAccuracy = kCLLocationAccuracyBest
            locationManager.distanceFilter = kCLDistanceFilterNone
            locationManager.startUpdatingLocation()
        }
    }
    
//to set user current location as source location for route
    @IBAction func fromBtn(_ sender: Any) {
        //getting user current location
        self.sourceLocation = self.locationManager.location?.coordinate
        currentLocationFlag = true
        getAddressFromLatLon(pdblLatitude: sourceLocation!.latitude, withLongitude: sourceLocation!.longitude)
        let location = locationManager.location?.coordinate
        let span:MKCoordinateSpan = MKCoordinateSpan(latitudeDelta: 0.01, longitudeDelta: 0.01)
        let myLocation:CLLocationCoordinate2D = CLLocationCoordinate2DMake((location?.latitude)!, (location?.longitude)!)
        let region:MKCoordinateRegion = MKCoordinateRegion(center: myLocation, span: span)
        mapView.setRegion(region, animated: true)
        self.locationManager.stopUpdatingLocation()
    }
    

    //to draw route on map
    @IBAction func toBtn(_ sender: Any) {
        //to removve all overlay from map
        for poll in mapView.overlays {
            mapView.removeOverlay(poll)
        }
        findLocationsAndGoToMap()
    }

    
    private func findLocationsAndGoToMap() {
        if currentLocationFlag {
            //if user selected current location then getting coordinates of it
            self.sourceLocation = self.locationManager.location?.coordinate
        } else {
            //to find user input source location
            dispatchGroup.enter()
            findSourceLocation()
        }
        
        //to find user inputed destination location
        dispatchGroup.enter()
        findDestinationLocation()
        dispatchGroup.notify(queue: .main) {
            if self.sourceLocation == nil {
                self.displayAlert(message: "Location access is not allowed")
            } else {
                //draw route on map
                self.drawRoute()
            }
        }
    }
    
    //finding user input source location on map function
    private func findSourceLocation() {
        let geocoder = CLGeocoder()
        
        geocoder.geocodeAddressString(fromField.text!) { (placemark, error) in
            guard let placemark = placemark else {
                if let error = error {
                    self.displayAlert(message: "wrong source location")
                    print(error)
                }
                return
            }
            //to mark start place
            let location = placemark[0].location
            self.sourceLocation = CLLocationCoordinate2D(latitude: location!.coordinate.latitude, longitude: location!.coordinate.longitude)
            self.dispatchGroup.leave()
        }
    }
    
    //find destination place on map function
    private func findDestinationLocation() {
        let geocoder = CLGeocoder()
        
        geocoder.geocodeAddressString(toField.text!) {(placemark, error) in
            guard let placemark = placemark else {
                if let error = error {
                    self.displayAlert(message: "wrong destination location")
                    print(error)
                }
                return
            }
            //set mark to destination location
            let location = placemark[0].location
            self.destinationLocation = CLLocationCoordinate2D(latitude: location!.coordinate.latitude, longitude: location!.coordinate.longitude)
            self.dispatchGroup.leave()
        }
    }
    
    
    //function to draw route on map
    func drawRoute() {
        //delegates,properties and objects
        mapView.delegate = self
        mapView.showsUserLocation = true
        let sourcePlaceMark = MKPlacemark(coordinate: sourceLocation!)
        let destinationPlaceMark = MKPlacemark(coordinate: destinationLocation!)
        let directionRequest = MKDirections.Request()
        directionRequest.source = MKMapItem(placemark: sourcePlaceMark)
        directionRequest.destination = MKMapItem(placemark: destinationPlaceMark)
        directionRequest.transportType = .automobile
        
        let directions = MKDirections(request: directionRequest)
        directions.calculate { (response, error) in
            guard let directionResponse = response else {
                if let error = error {
                    self.displayAlert(message: "cannot find any route")
                    print(error)
                }
                return
            }
            
            //adding route overlay on map
            let route = directionResponse.routes[0]
            self.mapView.addOverlay(route.polyline, level: .aboveRoads)
            
            //change view of map on route
            let rect = route.polyline.boundingMapRect
            self.mapView.setRegion(MKCoordinateRegion(rect), animated: true)
        }
    }
    
    //function to get current address from current latitude and longtitude
    func getAddressFromLatLon(pdblLatitude: Double, withLongitude pdblLongitude: Double) {
            var center : CLLocationCoordinate2D = CLLocationCoordinate2D()
            let lat = pdblLatitude
            let lon = pdblLongitude
            let ceo: CLGeocoder = CLGeocoder()
            center.latitude = lat
            center.longitude = lon

            let loc: CLLocation = CLLocation(latitude:center.latitude, longitude: center.longitude)

            ceo.reverseGeocodeLocation(loc, completionHandler:
                { (placemarks, error) in
                    if (error != nil)
                    {
                        print("reverse geodcode fail: \(error!.localizedDescription)")
                    }
                    let pm = placemarks! as [CLPlacemark]

                    if pm.count > 0 {
                        let pm = placemarks![0]
                        var addressString : String = ""
                        if pm.name != nil {
                            addressString = addressString + pm.name! + ", "
                        }
                        if pm.subLocality != nil {
                            addressString = addressString + pm.subLocality! + ", "
                        }
                        self.fromField.text = addressString
                        print(addressString)
                  }
            })

        }
    
    
   
    //for displaying alerts
    private func displayAlert(message: String)
    {
        let alert = UIAlertController(title: "Error", message: message, preferredStyle: UIAlertController.Style.alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default))
        self.present(alert, animated: true, completion: nil)
    }
    
    

    
    //on text field editing open new view for search
    func textFieldDidBeginEditing(_ textField: UITextField) {
        
        let searchViewController = storyBoard.instantiateViewController(withIdentifier: "SearchViewController") as! SearchViewController
        searchViewController.modalTransitionStyle = .coverVertical
        
        if textField == fromField {
            currentLocationFlag = false
            searchViewController.field = ("fromField", fromField.text) as? (String, String)
        }
        else {
            searchViewController.field = ("toField", toField.text) as? (String, String)
        }
        present(searchViewController, animated: true, completion: nil)
    }
    
    //properties for rendering overlay on map
    func mapView(_ mapView: MKMapView, rendererFor overlay: MKOverlay) -> MKOverlayRenderer {
        let renderer = MKPolylineRenderer(overlay: overlay)
        
        renderer.strokeColor = UIColor.blue
        renderer.lineWidth = 4.0
        return renderer
    }
    

    
}
