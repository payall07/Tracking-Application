//
//  PlacesOnMapViewController.swift
//  Final Project
//
//  Created by deep gandhi
//

import UIKit
import MapKit
import CoreLocation

// class to display user selected category's locations on map

class PlacesOnMapViewController: UIViewController, CLLocationManagerDelegate, UIGestureRecognizerDelegate {

    @IBOutlet weak var mapView: MKMapView!
    
    //objects
    let locationManager = CLLocationManager()
    var currentUserLocation = CLLocationCoordinate2D()
    
    // variables to store data
    var matchingItems : [MKMapItem] = []
    var nearByCategory = ""
    @IBOutlet weak var addressLabel: UILabel!
    var addressString = ""
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        //delegates and properties
        locationManager.delegate = self
        locationManager.desiredAccuracy = kCLLocationAccuracyBest
        locationManager.requestWhenInUseAuthorization()
        locationManager.requestLocation()
        locationManager.startUpdatingLocation()
        mapView.setUserTrackingMode(.follow, animated: true)
        
        // for map drag event
        let panGesture = UIPanGestureRecognizer(target: self, action: #selector(self.didDragMap(_:)))
        panGesture.delegate = self
        mapView.addGestureRecognizer(panGesture)
    
 
    }
    

    //for current user location and nearby places
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        //setting current location
        if let location = locations.first {
            let span = MKCoordinateSpan(latitudeDelta: 0.05, longitudeDelta: 0.05)
            let region = MKCoordinateRegion(center: location.coordinate, span: span)
            print(location.coordinate)
            currentUserLocation = location.coordinate
            mapView.setRegion(region, animated: true)
        }
    
        //finding nearby places of chosen category
        self.performSearch(category : nearByCategory)
        
        locationManager.stopUpdatingLocation()
    }
    
    
    //error handler
    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
        print("error : \(error)")
    }
    
    
    //to seatch nearby places with category/
    func performSearch(category : String) {
        
        matchingItems.removeAll()
        //search reques
        let request = MKLocalSearch.Request()
        request.naturalLanguageQuery = nearByCategory
        request.region = mapView.region
        
        
        let search = MKLocalSearch(request: request)
        
        search.start(completionHandler: {(response, error) in
            if let results = response {
                print(results)
                if let err = error {
                    print("Error occurred in search: \(err.localizedDescription)")
                } else if results.mapItems.count == 0 {
                    print("No matches found")
                } else {
                    print("Matches found")
                    //to store response list in array
                    for item in results.mapItems {
                        self.matchingItems.append(item as MKMapItem)
                        print("Matching items = \(self.matchingItems.count)")
                        
                        //to pin locations on map
                        let annotation = MKPointAnnotation()
                        annotation.coordinate = item.placemark.coordinate
                        annotation.title = item.name
                        self.mapView.addAnnotation(annotation)
                    }
                }
            }
        })
    }
    
    
    func gestureRecognizer(_ gestureRecognizer: UIGestureRecognizer, shouldRecognizeSimultaneouslyWith otherGestureRecognizer: UIGestureRecognizer) -> Bool {
        return true
    }
    
    //on map drag event
    @objc func didDragMap(_ sender: UIGestureRecognizer) {
        //to search again for places on drag end
        if sender.state == .ended {
        self.performSearch(category : nearByCategory)
        }
    }
 
}


   

