//
//  MyLocationViewController.swift
//  Final Project
//
//  Created by nishant patel.
//

// calss for address finder view in which app gets current user location and allow them to ppin a location to find it's address.


import UIKit

import MapKit
import CoreLocation

class MyLocationViewController: UIViewController,CLLocationManagerDelegate {
    
    
    //objects
    let locationManager = CLLocationManager()
    var currentUserLocation = CLLocationCoordinate2D()
    
    @IBOutlet weak var mapView: MKMapView!
    @IBOutlet weak var addressLabel: UILabel!
    
    //variable for storing address
    var addressString = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // requesting location permission
            locationManager.requestWhenInUseAuthorization()
        
        //delegates
            locationManager.delegate = self
            locationManager.desiredAccuracy = kCLLocationAccuracyBest
            locationManager.startUpdatingLocation()
            mapView.showsUserLocation = true
        
        	
        // long press event recognizer
        let longPressRecogniser = UILongPressGestureRecognizer(target: self, action: #selector(self.handleTap(_:)))
               longPressRecogniser.minimumPressDuration = 0.5
               mapView.addGestureRecognizer(longPressRecogniser)
         

      
    }
    
    //change map type on button click
    @IBAction func standardMap(_ sender: Any) {
        mapView.mapType = .standard
        
    }
    
    @IBAction func satelliteMap(_ sender: Any) {
        
        mapView.mapType = .satellite
    }
    
    @IBAction func hybridMap(_ sender: Any) {
        mapView.mapType = .hybrid
        
    }
    
    
    // for user current location
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        
        //for first location
        if let location = locations.first{
           // locationManager.stopUpdatingLocation()
        
            currentLocation(location)
        }

    }
    
    
    // function to find and navigate to user current location on initialization
    func currentLocation(_ location:CLLocation){
        
        // variables to store location details
        let coordinates = CLLocationCoordinate2D(latitude: location.coordinate.latitude, longitude: location.coordinate.longitude)
        let span = MKCoordinateSpan(latitudeDelta: 0.1, longitudeDelta: 0.1)
        let region = MKCoordinateRegion(center: coordinates, span: span)
   
        
        mapView.setRegion(region, animated: true)
        
        //  let pin = MKPointAnnotation()
        //pin.coordinate = coordinates
        //  mapView.addAnnotation(pin)
        
      //  convertLatLongToAddress(latitude: location.coordinate.latitude, longitude: location.coordinate.longitude)
        
    }
    
    
    @IBAction func btnDirection(_ sender: Any) {
      
    }
 
    
// function to convert latitude and longtitude to address
    
    func convertLatLongToAddress(latitude:Double,longitude:Double){
        // variables for location informaion
        let geoCoder = CLGeocoder()
        let location = CLLocation(latitude: latitude, longitude: longitude)
        geoCoder.reverseGeocodeLocation(location, completionHandler: { (placemarks, error) -> Void in
            
            // Place details
            var placeMark: CLPlacemark!
            placeMark = placemarks?[0]
            // Location name
            if let locationName = placeMark.name{
                self.addressString = locationName + ", "
                print(locationName)
            }
            // City
            if let city = placeMark.locality {
                self.addressString = self.addressString + city + ", "
                print(city)
            }
            // State
            if let state = placeMark.administrativeArea {
                self.addressString = self.addressString + state + ", "
                print(state)
            }
            // Country
            if let country = placeMark.country {
                self.addressString = self.addressString + country + "-"
                print(country)
            }
            // Zip code
            if let zipCode = placeMark.postalCode {
                self.addressString = self.addressString + zipCode + "."
                print(zipCode)
            }
          
        })
        
        print(self.addressString)
        // updating address text
        self.addressLabel.text = addressString
    }
    
 
 // function to handle long press
    @objc func handleTap(_ gestureReconizer: UILongPressGestureRecognizer)
    {
        //to get ordinates of pin
        self.mapView.removeAnnotations(self.mapView.annotations)
        let location = gestureReconizer.location(in: mapView)
        let coordinate = mapView.convert(location,toCoordinateFrom: mapView)
        print(coordinate)
        
        // Add pin
        let annotation = MKPointAnnotation()
        annotation.coordinate = coordinate
        annotation.title = "Selected Location"
        mapView.addAnnotation(annotation)
        
        
        //get location of pin
        convertLatLongToAddress(latitude: coordinate.latitude,longitude: coordinate.longitude)
        
    }
    
 
    

}

