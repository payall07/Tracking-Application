//
//  NearbyPlacesViewController.swift
//  Final Project
//
//  Created by Meet Patel.
//

// collection view class for nearby location categories which shows different elements in collection view

import UIKit

class NearbyPlacesViewController: UIViewController, UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {

    @IBOutlet weak var collectionView: UICollectionView!
    
    //category array
    var nearByArray = ["Hospital", "Airport", "Fire Brigade", "Police Station", "Hotel", "Bank", "University", "CourtHouse", "Bus stand", "Colleges", "Travel", "Mosques", "Atm", "Restaurants", "Book Shops", "Museum", "Beauty Saloon", "Health", "Laundry", "Market", "Lawyer", "Furniture", "Post Office", "Parking", "Car Repair", "Bakers", "Pharmacy", "Gym", "Doctor", "Railway Station", "Cafeteria", "Schools", "Food", "Clubs"]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //delegates
        collectionView.delegate = self
        collectionView.dataSource = self
    }
    
    //collection view items count
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        //returns count of category array for rows
        return nearByArray.count
    }
    
    
    //defining text to each collection view item
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "NearByCollectionCell", for: indexPath) as! NearByCollectionCell
        cell.label.text = nearByArray[indexPath.row]
        return cell
    }
    
    
    //on collection view item click
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        //opening new view of locations on item click with category value
        let sec:PlacesOnMapViewController = self.storyboard?.instantiateViewController(withIdentifier: "sec") as! PlacesOnMapViewController
        sec.nearByCategory = nearByArray[indexPath.row]
        
        self.navigationController?.pushViewController(sec, animated: true)
    }
    
  
}


//defining label of item
class NearByCollectionCell : UICollectionViewCell {
    
    @IBOutlet weak var label: UILabel!
    
}



